package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AI_DAO {
   
      private Connection conn;
      private PreparedStatement psmt;
      private ResultSet rs;

      private void getConnection() {
         try {
            // 0.(����)�ش�Ǵ� DBMS ����̹� ������ �� ������Ʈ�ȿ� �־��ֱ�
            // 1. ������� �����ε�(��� DBMS�� ����� ������ ����)
            Class.forName("oracle.jdbc.driver.OracleDriver");
            // 2. Ŀ�ؼ� ����(Java DataBase���� ��θ� ����)
            String db_url = "jdbc:oracle:thin:@172.30.1.29:1521:xe";
            String db_id = "hr";
            String db_pw = "hr";
            // conn -> java.sql
            conn = DriverManager.getConnection(db_url, db_id, db_pw);

         } catch (ClassNotFoundException e) {
            e.printStackTrace();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }

      private void close() {
         try {
            // 4. ��������
            if (rs != null) {
               rs.close();
            }
            if (psmt != null) {
               psmt.close();
            }
            if (conn != null) {
               conn.close();
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }

      }

      public int insert(AI_DTO dto) {
         
         int cnt = 0;
         getConnection();
         
         try {
            // 3. SQL�� �ۼ� �� ����
            String sql = "INSERT INTO AI_USER values(?, ?, ?, ?, ?)";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, dto.getId());
            psmt.setString(2, dto.getNick());
            psmt.setString(3, dto.getPw());
           
            psmt.setString(4, dto.getAge());
            psmt.setString(5, dto.getSex());
         
            // select ���� �����ϰ��� Update�� ����ϸ� �ȴ�.
             cnt = psmt.executeUpdate();
             
         } catch (SQLException e) {
            e.printStackTrace();
         } finally {
            close();
         }
         return cnt;
         
      }
      public int join(AI_DTO dto) {
         
         int cnt = 0; 
         getConnection();
         
         try {
            
            String sql = "INSERT INTO AI_USER VALUES(?,?,?,?,?)";
            psmt = conn.prepareStatement(sql);
            
            psmt.setString(1, dto.getId());
            psmt.setString(2, dto.getPw());
            psmt.setString(3, dto.getNick());
            psmt.setString(4, dto.getSex());
            psmt.setString(5, dto.getAge());
            
            System.out.println("id "+dto.getId());
            System.out.println("pw "+dto.getPw());
            System.out.println("nick "+dto.getNick());
            System.out.println("sex "+dto.getSex());
            System.out.println("age "+dto.getAge());
            
            
             

         cnt = psmt.executeUpdate();
         
         System.out.println("cnt : "+cnt);

         }catch (SQLException e) {
            e.printStackTrace();
         } finally {
            close();
         }
         return cnt;
      }
      public String login(AI_DTO dto) {
         String nick = null;
         getConnection();
         try {
            
            String sql = "SELECT * FROM AI_USER WHERE ID = ? AND PW = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, dto.getId());
            psmt.setString(2, dto.getPw());
            rs = psmt.executeQuery();
            
            if(rs.next()){
               nick = rs.getString(2);
            }
            
         }catch (SQLException e) {
            e.printStackTrace();
         }
         finally {
            close();
         }
         return nick;
      }
      
      

   
   
}