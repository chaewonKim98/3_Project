package com;

public class TEST_DTO {
      private String id;
      private String test_num;
      private String test_chart1;
      private String test_chart2;
      public TEST_DTO(String id, String test_num, String test_chart1, String test_chart2) {
      
      this.id = id;
      this.test_num = test_num;
      this.test_chart1 = test_chart1;
      this.test_chart2 = test_chart2;
   }
   
   public TEST_DTO(String test_num, String test_chart1, String test_chart2) {
      
      this.test_num = test_num;
      this.test_chart1 = test_chart1;
      this.test_chart2 = test_chart2;
   }
   public String getId() {
      return id;
   }
   public String getTest_num() {
      return test_num;
   }
   public String getTest_chart1() {
      return test_chart1;
   }
   public String getTest_chart2() {
      return test_chart2;
   }
      
      
      
      
   
}