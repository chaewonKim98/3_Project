package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class TEST_DAO {
    private Connection conn;
      private PreparedStatement psmt;
      private ResultSet rs;

      private void getConnection() {
         try {
            // 0.(����)�ش�Ǵ� DBMS ����̹� ������ �� ������Ʈ�ȿ� �־��ֱ�
            // 1. ������� �����ε�(��� DBMS�� ����� ������ ����)
            Class.forName("oracle.jdbc.driver.OracleDriver");
            // 2. Ŀ�ؼ� ����(Java DataBase���� ��θ� ����)
            String db_url = "jdbc:oracle:thin:@172.30.1.29:1521:xe";
            String db_id = "hr";
            String db_pw = "hr";
            // conn -> java.sql
            conn = DriverManager.getConnection(db_url, db_id, db_pw);

         } catch (ClassNotFoundException e) {
            e.printStackTrace();
         } catch (SQLException e) {
            e.printStackTrace();
         }
      }

      private void close() {
         try {
            // 4. ��������
            if (rs != null) {
               rs.close();
            }
            if (psmt != null) {
               psmt.close();
            }
            if (conn != null) {
               conn.close();
            }
         } catch (SQLException e) {
            e.printStackTrace();
         }

      }
      public TEST_DTO getpass(String id) {   
         getConnection();
         String sql = "SELECT * FROM TEST_INFO WHERE id=?";
         TEST_DTO dto = null;
         try {
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, id);
            rs = psmt.executeQuery();
            
            if(rs.next()){
            String   getTest_num= rs.getString("test_num");
            String   getTest_chart1= rs.getString("test_chart1");
            String   getTest_chart2= rs.getString("test_chart2");
            
            dto = new TEST_DTO(getTest_num,getTest_chart1,getTest_chart2);
            }
            
         }catch (SQLException e) {
            e.printStackTrace();
         }
         finally {
            close();
         }
         return dto;
      }

   
      

}