package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/test_view")
public class test_view extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      /*
       * String test_num = request.getParameter("test_num"); String test_chart1 =
       * request.getParameter("test_chart1"); String test_chart2 =
       * request.getParameter("test_chart2");
       */
      HttpSession session = request.getSession();
      String id = (String)session.getAttribute("id");
      
      TEST_DAO dao = new TEST_DAO();
      TEST_DTO dto = dao.getpass(id);
      
      
      
      //session.setAttribute("DTO", dto);
      
      
      String str = (String) session.getAttribute("ID");
      
      
      
      if(dto != null) {
         //response.sendRedirect("TEST_IMG.jsp");
         request.setAttribute("DTO", dto);
         RequestDispatcher rd = request.getRequestDispatcher("Final.jsp");
         rd.forward(request, response);
      }else {
         response.sendRedirect("main.jsp");
      }
   }

}