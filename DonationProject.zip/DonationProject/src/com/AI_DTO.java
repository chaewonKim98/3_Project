package com;

public class AI_DTO {
      private String id;
      private String pw;
      private String nick;
      private String sex;
      private String age;
      
      
      
      public AI_DTO(String id, String pw, String nick,  String sex,String age) {
         this.id = id;
         this.pw = pw;
         this.nick = nick;
         this.age = age;
         this.sex = sex;
      }

      public AI_DTO(String id, String pw) {
      this.id = id;
      this.pw = pw;
   }

   public String getId() {
         return id;
      }

      public String getPw() {
         return pw;
      }

      public String getNick() {
         return nick;
      }

      public String getAge() {
         return age;
      }

      public String getSex() {
         return sex;
      }

   
}